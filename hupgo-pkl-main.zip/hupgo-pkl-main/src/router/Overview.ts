export default [
    {
        path: "/homedashboard",
        name: "homedashboard",
        component: () => import("@/views/Dashboard/HomeDashboard.vue"),
    }
]