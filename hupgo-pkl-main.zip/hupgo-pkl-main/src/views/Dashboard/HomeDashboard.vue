<template>
  <div class="row gy-5 g-xl-12">
    <div class="position-relative">
      <div class="row">
      </div>
    </div>
  </div>
</template>
<script>
import { setCurrentPageTitle } from "@/core/helpers/breadcrumb";

export default {
  setup() {
    setCurrentPageTitle("Home Dashboard");
    return {
    };
  },
};
</script>
