<template>
  <div class="row gy-5 g-xl-10">
    <div class="col-xl-12 mb-xl-12">
      <div class="card card-flush h-xl-100">
        <!--begin::Card header-->
        <div class="card-header border-0">
          <div class="d-flex align-items-center">
            <router-link
              :to="{ name: 'master-category-formula-add' }"
              class="btn btn-sm btn-light-primary"
            >
              <span class="svg-icon svg-icon-2">
                <inline-svg src="/media/icons/duotune/arrows/arr075.svg" />
              </span>
              Create
            </router-link>
          </div>
        </div>
        <!--end::Card header-->
        <!--begin::Card body-->
        <div class="card-body pt-0">
          <KTDatatable
            :table-data="tableData"
            :table-header="tableHeader"
            :loading="loading"
          >
            <template v-slot:cell-actions="{ row: val }">
              <button
                @click.prevent="destroy(val.id, index)"
                class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1"
                title="Delete"
              >
                <span class="svg-icon svg-icon-3">
                  <inline-svg src="/media/icons/duotune/general/gen027.svg" />
                </span>
              </button>
              <router-link
                :to="{ name: 'master-category-formula-edit', params: { id: val.id } }"
                class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
              >
                <span class="svg-icon svg-icon-3">
                  <inline-svg src="/media/icons/duotune/art/art005.svg" />
                </span>
              </router-link>
            </template>
            <template v-slot:cell-kpi_perspective="{ row: val }">
              {{ val.kpi_perspective }}
            </template>
            <template v-slot:cell-kpi_category="{ row: val }">
              {{ val.kpi_category }}
            </template>
          </KTDatatable>
        </div>
        <!--end::Card body-->
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import axios from "axios";
import Swal from "sweetalert2/dist/sweetalert2.min.js";
import KTDatatable from "@/components/kt-datatable/KTDatatable.vue";

import { defineComponent, ref, onMounted, computed } from "vue";
import { setCurrentPageTitle } from "@/core/helpers/breadcrumb";

export default defineComponent({
  components: {
    KTDatatable,
  },
  setup() {
    onMounted(() => {
      setCurrentPageTitle("List Category & Formula");
      indexCategoryAndFormula();
    });

    let data = ref([]);
    let loading = ref();

    const tableHeader = ref([
      {
        name: "Action",
        key: "actions",
      },
      {
        name: "KPI Perspective",
        key: "kpi_perspective",
      },
      {
        name: "KPI Category",
        key: "kpi_category",
      },
      {
        name: "KPI Item Category",
        key: "kpi_item_category",
      },
      {
        name: "Weight",
        key: "weight",
      },
      {
        name: "MTD % Formula",
        key: "mtd_option",
      },
      {
        name: "YTD % Formula",
        key: "ytd_option",
      },
      {
        name: "Active/Non-active",
        key: "is_active",
      },
      {
        name: "KPI Focus Item",
        key: "shown_in_focus",
      },
    ]);

    const tableData = computed(() => {
      let post = data.value;
      return post;
    });

    const indexCategoryAndFormula = () => {
      //   loading.value = true;
      //   axios
      //     .get("/cost-monitoring/blasting/pic")
      //     .then((response) => {
      //       loading.value = false;
      //       data.value = response.data;
      //     })
      //     .catch((error) => {
      //       loading.value = false;
      //       console.log(error);
      //     });
    };

    const destroy = (id) => {
      Swal.fire({
        title: "Are you sure?",
        text: "This record and it`s details will be permanantly deleted!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, cancel!",
        reverseButtons: true,
      }).then(function (result) {
        if (result.value) {
          axios.delete("/cost-monitoring/blasting/pic/delete/" + id);
          let deleteIndex = data.value.findIndex((row) => row["id"] === id);
          data.value.splice(deleteIndex, 1);
          Swal.fire("Deleted!", "Your data has been deleted.", "success");
        } else if (result.dismiss === "cancel") {
          Swal.fire("Cancelled", "Your imaginary data is safe :)", "error");
        }
      });
    };

    return {
      data,
      destroy,
      loading,
      tableHeader,
      tableData,
    };
  },
});
</script>
