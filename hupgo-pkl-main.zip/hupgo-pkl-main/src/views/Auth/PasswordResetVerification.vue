<template>
  <div class="d-flex flex-column flex-lg-row-fluid">
    <div class="d-flex flex-column flex-root" id="background">
      <!--begin::Page bg image-->

      <!--end::Page bg image-->
      <!--begin::Authentication - Sign-in -->
      <div class="d-flex flex-column flex-column-fluid flex-lg-row">
        <!--begin::Aside-->
        <div class="d-flex flex-center w-lg-50 pt-15 pt-lg-0 px-10">
          <!--begin::Aside-->
          <div class="d-flex flex-center flex-lg-start flex-column">
            <!--begin::Logo-->
            <div class="mb-5">
              <v-lazy-image
                src="/media/logos/hupgotextgradasi.png"
                style="height: 55px"
              />
            </div>
            <!--end::Logo-->
            <!--begin::Title-->
            <h2 class="text-white fw-normal m-0">Digital Application for Mining Industry</h2>
            <!--end::Title-->
          </div>
          <!--begin::Aside-->
        </div>
        <!--begin::Aside-->
        <!--begin::Body-->
        <div
          class="d-flex flex-column-fluid flex-lg-row-auto justify-content-center justify-content-lg-end p-12 p-lg-20"
        >
          <!--begin::Card-->
          <div
            class="bg-body d-flex flex-column align-items-stretch flex-center rounded-4 w-md-600px p-20"
          >
            <!--begin::Wrapper-->
            <div class="d-flex flex-center flex-column flex-column-fluid px-lg-10 pb-10">
              <!--begin::Form-->
              <Form
                class="form w-70 fv-plugins-bootstrap5 fv-plugins-framework"
                @submit="onSubmitForgotPassword"
                id="kt_login_password_reset_form"
                :validation-schema="forgotPassword"
              >
                <!--begin::Heading-->
                <div class="text-center mb-3">
                  <!--begin::Title-->
                  <h1 class="text-dark mb-3">Verification</h1>
                  <!--end::Title-->

                  <!--begin::Link-->
                  <div class="text-gray-400 fw-bold fs-4">
                    Enter your code and new password.
                  </div>
                  <!--end::Link-->
                </div>
                <!--begin::Heading-->

                <!--begin::Input group-->
                <div class="fv-row mb-3">
                  <div class="fv-row mb-8 fv-plugins-icon-container">
                    <Field
                      v-model="post.code"
                      class="form-control form-control-solid"
                      type="number"
                      placeholder="Code sent to your email"
                      name="code"
                      autocomplete="off"
                    />
                    <div class="fv-plugins-message-container">
                      <div class="fv-help-block">
                        <ErrorMessage name="code" />
                      </div>
                    </div>
                  </div>
                </div>
                <!--end::Input group-->

                <!--begin::Input group-->
                <div class="mb-3 fv-row" data-kt-password-meter="true">
                  <!--begin::Wrapper-->
                  <div class="fv-row mb-8 fv-plugins-icon-container">
                    <!--begin::Input wrapper-->
                    <div class="position-relative mb-3">
                      <Field
                        v-model="post.password"
                        class="form-control form-control-lg form-control-solid"
                        type="password"
                        placeholder="Enter your new password"
                        name="password"
                        autocomplete="off"
                      />
                      <div class="fv-plugins-message-container">
                        <div class="fv-help-block">
                          <ErrorMessage name="password" />
                        </div>
                      </div>
                      <!--end::Input wrapper-->
                      <!--begin::Meter-->
                      <div
                        class="d-flex align-items-center mb-3"
                        data-kt-password-meter-control="highlight"
                      >
                        <div
                          class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"
                        ></div>
                        <div
                          class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"
                        ></div>
                        <div
                          class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"
                        ></div>
                        <div
                          class="flex-grow-1 bg-secondary bg-active-success rounded h-5px"
                        ></div>
                      </div>
                      <!--end::Meter-->
                    </div>
                  </div>
                  <!--end::Wrapper-->
                  <!--begin::Hint-->
                  <div class="text-muted">
                    Use 8 or more characters with a mix of letters, numbers & symbols.
                  </div>
                  <!--end::Hint-->
                </div>
                <!--end::Input group--->
                <br />
                <!--begin::Actions-->
                <div class="d-flex flex-wrap justify-content-center pb-lg-0">
                  <button
                    type="submit"
                    ref="submitButton"
                    class="btn btn-lg btn-primary fw-bolder me-4"
                  >
                    <span class="indicator-label"> Submit </span>
                    <span class="indicator-progress">
                      Please wait...
                      <span
                        class="spinner-border spinner-border-sm align-middle ms-2"
                      ></span>
                    </span>
                  </button>

                  <router-link
                    to="/sign-in"
                    class="btn btn-lg btn-light-primary fw-bolder"
                    >Cancel</router-link
                  >
                </div>
                <!--end::Actions-->
              </Form>
              <!--end::Form-->
            </div>
            <!--end::Wrapper-->
            <!--begin::Footer-->
            <div class="d-flex flex-center flex-wrap fs-6 p-5 pb-3">
              <div class="text-gray-400 d-flex flex-center fw-bold fs-6">
                Copyright © {{ new Date().getFullYear() }} - Powered by CMIS
              </div>
            </div>
            <!--end::Footer-->
          </div>
          <!--end::Card-->
        </div>
        <!--end::Body-->
      </div>
      <!--end::Authentication - Sign-in-->
    </div>
  </div>
</template>

<script lang="ts">
import axios from "axios";
import * as Yup from "yup";
import Swal from "sweetalert2/dist/sweetalert2.min.js";

import { defineComponent, ref, onMounted, nextTick, reactive } from "vue";
import { ErrorMessage, Field, Form } from "vee-validate";
import { useRouter } from "vue-router";
import { PasswordMeterComponent } from "@/assets/ts/components";
import { getIllustrationsPathAuth } from "@/core/helpers/assets";

export default defineComponent({
  name: "password-reset",
  components: {
    Field,
    Form,
    ErrorMessage,
  },
  setup() {
    const router = useRouter();

    const submitButton = ref<HTMLButtonElement | null>(null);

    let post = reactive({
      code: "",
      password: "",
    });

    onMounted(() => {
      nextTick(() => {
        PasswordMeterComponent.bootstrap();
      });
    });

    //Create form validation object
    const forgotPassword = Yup.object().shape({
      code: Yup.number().required().label("Code"),
      password: Yup.string().required().label("Password"),
    });

    //Form submit function
    const onSubmitForgotPassword = () => {
      // eslint-disable-next-line
      submitButton.value!.disabled = true;
      // Activate loading indicator
      submitButton.value?.setAttribute("data-kt-indicator", "on");

      // dummy delay
      // setTimeout(() => {
      // Send login request

      const bodyForm = {
        code: post.code,
        new_password: post.password,
      };
      axios
        .post("password/reset", bodyForm)
        .then((res) => {
          if (res.data.status == "Success") {
            Swal.fire({
              text: res.data.message,
              icon: "success",
              buttonsStyling: false,
              confirmButtonText: "Ok, got it!",
              customClass: {
                confirmButton: "btn fw-bold btn-light-primary",
              },
            }).then(() => {
              submitButton.value?.removeAttribute("data-kt-indicator");
              // eslint-disable-next-line
              submitButton.value!.disabled = false;
              router.push({ name: "sign-in" });
            });
          } else {
            // Alert then login failed
            Swal.fire({
              text: res.data.message,
              icon: "error",
              buttonsStyling: false,
              confirmButtonText: "Try again!",
              customClass: {
                confirmButton: "btn fw-bold btn-light-danger",
              },
            });
            submitButton.value?.removeAttribute("data-kt-indicator");
            // eslint-disable-next-line
            submitButton.value!.disabled = false;
          }
        })
        .catch((error) => {
          console.log(error);
          submitButton.value?.removeAttribute("data-kt-indicator");
          // eslint-disable-next-line
          submitButton.value!.disabled = false;
        });

      // }, 2000);
    };

    return {
      post,
      onSubmitForgotPassword,
      forgotPassword,
      submitButton,
      getIllustrationsPathAuth,
    };
  },
});
</script>

<style>
.ilustration {
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 0.8;
  max-width: 500px;
  min-width: 250px;
  margin: auto;
}

#background {
  background-image: url("../../../public/media/coal-bg.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
}
</style>
