<template>
  <!--begin::details View-->
  <div class="card mb-5 mb-md-10">
    <!--begin::Card header-->
    <div
      data-bs-toggle="collapse"
      data-bs-target="#kt_account_profile_details"
      class="card-header cursor-pointer"
    >
      <!--begin::Card title-->
      <div class="card-title m-0">
        <h3 class="fw-bolder m-0">Profile Details</h3>
      </div>
      <!--end::Card title-->
    </div>
    <!--begin::Card header-->

    <!--begin::Content-->
    <div id="kt_account_profile_details" class="collapse show">
      <!--begin::Card body-->
      <div class="card-body">
        <div class="col-md-12">
          <div class="d-flex justify-content-center">
            <div class="col-md-3 p-5">
              <div class="text-center align-middle">
                <div
                  class="symbol symbol-100px symbol-lg-200px symbol-fixed position-relative"
                >
                  <v-lazy-image src="/media/avatars/avatar-1.png" alt="image" />
                  <div
                    class="position-absolute translate-middle bottom-0 start-100 mb-6 bg-success rounded-circle border border-4 border-white h-20px w-20px"
                  ></div>
                </div>
              </div>
            </div>
            <div class="col-md-9 p-5">
              <!--begin::Row-->
              <div class="row p-2">
                <!--begin::Label-->
                <label class="col-lg-4 fw-bold text-muted">Full Name</label>
                <!--end::Label-->

                <!--begin::Col-->
                <div class="col-lg-8">
                  <span class="fw-bolder fs-6 text-dark">{{ user.name }}</span>
                </div>
                <!--end::Col-->
              </div>
              <div class="row p-2">
                <!--begin::Label-->
                <label class="col-lg-4 fw-bold text-muted">Nik</label>
                <!--end::Label-->

                <!--begin::Col-->
                <div class="col-lg-8">
                  <span class="fw-bolder fs-6 text-dark">{{ user.nik }}</span>
                </div>
                <!--end::Col-->
              </div>
              <div class="row p-2">
                <!--begin::Label-->
                <label class="col-lg-4 fw-bold text-muted">Company</label>
                <!--end::Label-->

                <!--begin::Col-->
                <div class="col-lg-8">
                  <span class="fw-bolder fs-6 text-dark">{{ user.company }}</span>
                </div>
                <!--end::Col-->
              </div>
              <div class="row p-2">
                <!--begin::Label-->
                <label class="col-lg-4 fw-bold text-muted">Site</label>
                <!--end::Label-->

                <!--begin::Col-->
                <div class="col-lg-8">
                  <span class="fw-bolder fs-6 text-dark">{{ user.SiteId }}</span>
                </div>
                <!--end::Col-->
              </div>
              <div class="row p-2">
                <!--begin::Label-->
                <label class="col-lg-4 fw-bold text-muted">Department</label>
                <!--end::Label-->

                <!--begin::Col-->
                <div class="col-lg-8">
                  <span class="fw-bolder fs-6 text-dark"
                    >{{ user.deptCode }} - {{ user.deptName }}</span
                  >
                </div>
                <!--end::Col-->
              </div>
              <div class="row p-2">
                <!--begin::Label-->
                <label class="col-lg-4 fw-bold text-muted">Position</label>
                <!--end::Label-->

                <!--begin::Col-->
                <div class="col-lg-8">
                  <span class="fw-bolder fs-6 text-dark">{{ user.Position }}</span>
                </div>
                <!--end::Col-->
              </div>
              <!--end::Row-->
            </div>
          </div>
        </div>
      </div>
      <!--end::Card body-->
    </div>
    <!--end::Content-->
  </div>
  <!--end::details View-->

  <!--begin::Settings Method-->
  <div class="card mb-5 mb-md-10">
    <!--begin::Card header-->
    <div
      class="card-header border-0 cursor-pointer"
      role="button"
      data-bs-toggle="collapse"
      data-bs-target="#kt_account_settings"
    >
      <div class="card-title m-0">
        <h3 class="fw-boldest m-0">Setting</h3>
      </div>
    </div>
    <!--end::Card header-->

    <!--begin::Content-->
    <div id="kt_account_settings" class="collapse show">
      <!--begin::Card body-->
      <div class="card-body border-top p-9">
        <!--begin::Email Address-->
        <div class="d-flex flex-wrap align-items-center mb-8">
          <div id="kt_signin_email">
            <div class="fs-4 fw-boldest mb-1">Email Address</div>
            <div class="fs-6 fw-bold text-gray-600">{{ user.Email }}</div>
          </div>
        </div>
        <!--end::Email Address-->

        <!--begin::Password-->
        <div class="d-flex flex-wrap align-items-center mb-8">
          <div id="kt_signin_password" :class="{ 'd-none': passwordFormDisplay }">
            <div class="fs-4 fw-boldest mb-1">Password</div>
            <div class="fs-6 fw-bold text-gray-600">************</div>
          </div>
          <div
            id="kt_signin_password_edit"
            class="flex-row-fluid"
            :class="{ 'd-none': !passwordFormDisplay }"
          >
            <div class="fs-6 fw-bold text-gray-600 mb-4">
              Password must be at least 8 character and contain symbols
            </div>

            <!--begin::Form-->
            <Form
              id="kt_signin_change_password"
              class="form"
              novalidate="novalidate"
              @submit="updatePassword()"
              :validation-schema="changePassword"
            >
              <div class="row mb-6">
                <div class="col-lg-4">
                  <div class="fv-row mb-0">
                    <label for="currentpassword" class="form-label fs-6 fw-bolder mb-3"
                      >Current Password</label
                    >
                    <Field
                      type="password"
                      v-model="post.current_password"
                      class="form-control form-control-lg form-control-solid fw-bold fs-6"
                      name="currentpassword"
                      id="currentpassword"
                    />
                    <div class="fv-plugins-message-container">
                      <div class="fv-help-block">
                        <ErrorMessage name="currentpassword" />
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="fv-row mb-0">
                    <label for="newpassword" class="form-label fs-6 fw-bolder mb-3"
                      >New Password</label
                    >
                    <Field
                      type="password"
                      v-model="post.new_password"
                      class="form-control form-control-lg form-control-solid fw-bold fs-6"
                      name="newpassword"
                      id="newpassword"
                    />
                    <div class="fv-plugins-message-container">
                      <div class="fv-help-block">
                        <ErrorMessage name="newpassword" />
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="fv-row mb-0">
                    <label for="confirmpassword" class="form-label fs-6 fw-bolder mb-3"
                      >Confirm New Password</label
                    >
                    <Field
                      type="password"
                      v-model="post.password_confirmation"
                      class="form-control form-control-lg form-control-solid fw-bold fs-6"
                      name="confirmpassword"
                      id="confirmpassword"
                    />
                    <div class="fv-plugins-message-container">
                      <div class="fv-help-block">
                        <ErrorMessage name="confirmpassword" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="d-flex">
                <button
                  id="kt_password_submit"
                  type="submit"
                  ref="updatePasswordButton"
                  class="btn btn-primary me-2 px-6"
                >
                  <span class="indicator-label"> Update Password </span>
                  <span class="indicator-progress">
                    Please wait...
                    <span
                      class="spinner-border spinner-border-sm align-middle ms-2"
                    ></span>
                  </span>
                </button>
                <button
                  id="kt_password_cancel"
                  type="button"
                  @click="passwordFormDisplay = !passwordFormDisplay"
                  class="btn btn-color-gray-400 btn-active-light-primary px-6"
                >
                  Cancel
                </button>
              </div>
            </Form>
            <!--end::Form-->
          </div>
          <div
            id="kt_signin_password_button"
            class="ms-auto"
            :class="{ 'd-none': passwordFormDisplay }"
          >
            <button
              @click="passwordFormDisplay = !passwordFormDisplay"
              class="btn btn-light fw-boldest"
            >
              Change Password
            </button>
          </div>
        </div>
        <!--end::Password-->
      </div>
      <!--end::Card body-->
    </div>
    <!--end::Content-->
  </div>
  <!--end::Settings Method-->
</template>

<script lang="ts">
import { defineComponent, onMounted, ref, reactive } from "vue";
import { ErrorMessage, Field, Form } from "vee-validate";
import { setCurrentPageTitle } from "@/core/helpers/breadcrumb";
import Swal from "sweetalert2/dist/sweetalert2.js";
import * as Yup from "yup";
import axios from "axios";

export default defineComponent({
  name: "account-overview",
  components: {
    ErrorMessage,
    Field,
    Form,
  },
  setup() {
    let post = reactive({
      current_password: "",
      new_password: "",
      password_confirmation: "",
    });

    const updatePasswordButton = ref<HTMLElement | null>(null);

    const passwordFormDisplay = ref(false);

    const changePassword = Yup.object().shape({
      currentpassword: Yup.string().required().label("Current password"),
      newpassword: Yup.string().min(8).required().label("Password"),
      confirmpassword: Yup.string()
        .min(8)
        .required()
        .oneOf([Yup.ref("newpassword"), null], "Passwords must match")
        .label("Password Confirmation"),
    });

    onMounted(() => {
      setCurrentPageTitle("User Profile");
    });

    const user = JSON.parse(window.localStorage.getItem("user") || "{}");

    const updatePassword = () => {
      if (updatePasswordButton.value) {
        // Activate indicator
        updatePasswordButton.value.setAttribute("data-kt-indicator", "on");
        axios
          .post("/change-password", {
            current_password: post.current_password,
            new_password: post.new_password,
            password_confirmation: post.password_confirmation,
          })
          .then((res) => {
            if (res.data.result == true) {
              Swal.fire({
                text: res.data.message,
                icon: "success",
                confirmButtonText: "Ok",
                buttonsStyling: false,
                customClass: {
                  confirmButton: "btn btn-light-primary",
                },
              }).then(() => {
                post.current_password = "";
                post.new_password = "";
                post.password_confirmation = "";
                updatePasswordButton.value?.removeAttribute("data-kt-indicator");
                passwordFormDisplay.value = false;
              });
            } else {
              Swal.fire({
                text: res.data.message,
                icon: "error",
                confirmButtonText: "Ok",
                buttonsStyling: false,
                customClass: {
                  confirmButton: "btn btn-light-primary",
                },
              });
              updatePasswordButton.value?.removeAttribute("data-kt-indicator");
            }
          })
          .catch((error) => {
            console.log(error);
            updatePasswordButton.value?.removeAttribute("data-kt-indicator");
          });
      }
    };

    return {
      post,
      user,
      passwordFormDisplay,
      changePassword,
      updatePasswordButton,
      updatePassword,
    };
  },
});
</script>
