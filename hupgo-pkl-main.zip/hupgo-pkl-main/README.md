# Metronic

### Compiles and hot-reloads for development

```
npm run serve
```
#Metronic Doc

```
https://preview.keenthemes.com/metronic8/vue/docs/#/build
```
